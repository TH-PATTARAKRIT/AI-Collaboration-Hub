# 12_Knowledge_Base

Project SMEPLUS-26-06-29-001 Phase B Full Knowledge Base v1.4.
